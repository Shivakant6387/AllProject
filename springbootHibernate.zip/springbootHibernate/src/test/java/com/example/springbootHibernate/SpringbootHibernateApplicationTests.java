package com.example.springbootHibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
