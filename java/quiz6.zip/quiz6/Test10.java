package quiz6;

class Paper {
 String getType() { //Line n1
        return "Pramod";
        }
        }

class RuledPaper extends Paper {
    String getType() { //Line n2
        return "Pradhan";
    }
}

public class Test10 {
    public static void main(String[] args) {
        Paper paper = new RuledPaper(); //Line n3
        System.out.println(paper.getType()); //Line n4
    }
}

