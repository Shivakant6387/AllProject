package quiz6;

class Super4 {
   final  int NUM = -1; //Line n1
}

class Sub1 extends Super4 {
   int NUM = 100;
}

public class Test9 {
    public static void main(String[] args) {
        Sub1 obj = new Sub1();
        obj.NUM = 200; //Line n2
        System.out.println(obj.NUM); //Line n3
    }
}
