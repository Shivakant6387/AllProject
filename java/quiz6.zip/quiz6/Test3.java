package quiz6;

public class Test3 {
}
