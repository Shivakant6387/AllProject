package quiz6;

abstract class Food {
    protected abstract double getCalories();
}

class JunkFood extends Food {
    protected   double getCalories() {
        return 200.0;
    }
}

public class Test1 {

    public static void main(String[] args) {
        Food jf = new JunkFood();
        System.out.println(jf.getCalories());

    }
}

