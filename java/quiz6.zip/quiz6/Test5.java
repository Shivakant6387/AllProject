package quiz6;

class X {
    void A() {
        System.out.print("A");
    }
}

class Y extends X {
    void A() {
        System.out.print("A-");
    }

    void B() {
        System.out.print("B-");
    }

    void C() {
        System.out.print("C-");
    }
}

public class Test5 {
    public static void main(String[] args) {
        Y obj = new Y();
        obj.A();
        obj.B();
        obj.C();
    }
}
